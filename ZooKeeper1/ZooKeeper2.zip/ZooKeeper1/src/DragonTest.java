
public class DragonTest {

	public static void main(String[] args) {
		Dragon dragon = new Dragon();
		dragon.attackTown();
		dragon.displayEnergy();
		dragon.attackTown();
		dragon.displayEnergy();
		dragon.attackTown();
		dragon.displayEnergy();
		dragon.eatHumans();
		dragon.displayEnergy();
		dragon.eatHumans();
		dragon.displayEnergy();
		dragon.fly();
		dragon.displayEnergy();
		dragon.fly();
		dragon.displayEnergy();
	}

}
