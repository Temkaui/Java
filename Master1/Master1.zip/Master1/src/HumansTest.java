
public class HumansTest {

	public static void main(String[] args) {
		Human human = new Human();
		Human human1 = new Human();
		human.attack(human1);
		human1.displayHealth();
	}

}
