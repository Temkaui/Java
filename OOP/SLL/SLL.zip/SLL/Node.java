public class Node{
	public int val;
	public Node next;

	public Node(){}

	public Node(Integer value){
		this.val = value;
		this.next = null;
	}

}
