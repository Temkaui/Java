public class JavaProgramLifeCycle{
	public static void main(String[] args){
		System.out.println("My name is Coding Dojo");
		System.out.println("i'm 100 years old");
	}
}