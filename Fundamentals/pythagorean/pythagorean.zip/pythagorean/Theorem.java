import java.lang.Math;
public class Theorem {
    public double calculate(int a, int b) {
    	double c = a*a+b*b;
    	double r = Math.sqrt(c);
    	return r;
    }
}
