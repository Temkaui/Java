public class TheoremTest {
	public static void main(String[] args){
		Theorem p = new Theorem();
		double result = p.calculate(3,4);
		System.out.println(result);
	}
}