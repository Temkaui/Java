public class FizzBuzzTest{
	public static void main(String[] args){
		FizzBuzz pass = new FizzBuzz();
		String result = pass.fizzBuzz(4);
		System.out.println(result);
	}
}